<?php if ( ! defined( 'ABSPATH' ) ) {
	die( 'Forbidden' );
}
