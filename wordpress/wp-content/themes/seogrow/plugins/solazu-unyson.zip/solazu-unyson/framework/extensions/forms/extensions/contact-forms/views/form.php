<?php if ( ! defined( 'ABSPATH' ) ) {
	die( 'Forbidden' );
}
/**
 * @var string $form_id
 * @var string $form_html
 * @var array $extra_data
 */
?>
<div class="form-wrapper contact-form">
	<?php echo $form_html; ?>
</div>