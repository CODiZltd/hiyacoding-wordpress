<?php if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$manifest = array(
	'version'       => '1.0.0',
	'display'       => false,
	'standalone'    => true,
	'requirements'  => array(
		'extensions' => array(
			// 'autoload'          => array()
		)
	),
	// 'github_update' => 'ThemeFuse/Unyson-Shortcodes-Extension'
);
