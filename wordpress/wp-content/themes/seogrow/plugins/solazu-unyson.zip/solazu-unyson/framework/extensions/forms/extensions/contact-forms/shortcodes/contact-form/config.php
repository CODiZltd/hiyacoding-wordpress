<?php if ( ! defined( 'ABSPATH' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => __( 'Contact form', 'slz' ),
	'description' => __( 'Build contact forms', 'slz' ),
	'tab'         => __( 'Content Elements', 'slz' ),
	'popup_size'  => 'large',
	'type'        => 'special'
);