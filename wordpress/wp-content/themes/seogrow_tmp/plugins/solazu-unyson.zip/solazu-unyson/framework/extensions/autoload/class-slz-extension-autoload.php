<?php if (!defined('SLZ')) die('Forbidden');

class SLZ_Extension_Autoload extends SLZ_Extension {
	
	protected function _init() {
	}

}
