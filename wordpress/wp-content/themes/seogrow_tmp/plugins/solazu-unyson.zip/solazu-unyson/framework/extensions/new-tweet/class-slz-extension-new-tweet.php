<?php if (!defined('SLZ')) die('Forbidden');

class SLZ_Extension_New_Tweet extends SLZ_Extension {
	
	protected function _init() {
	}

}
