<?php if (!defined('SLZ')) die('Forbidden');

class SLZ_Extension_Instagram extends SLZ_Extension {
	
	protected function _init() {
	}

}
