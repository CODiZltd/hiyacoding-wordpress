<?php if ( ! defined( 'SLZ' ) ) {
	die( 'Forbidden' );
}

$manifest = array();

$manifest['standalone'] = true;
