<?php if (!defined('SLZ')) die('Forbidden');
/**
 * @var string $items_html
 */
?>
<div class="wrap-forms">
	<?php echo $items_html ?>
</div>